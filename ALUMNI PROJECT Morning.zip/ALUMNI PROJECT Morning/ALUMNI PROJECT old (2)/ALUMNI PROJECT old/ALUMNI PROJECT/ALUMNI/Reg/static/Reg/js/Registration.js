function next_step1() {
    // Get input field values
    var fname = document.getElementsByName('fname')[0].value;
    var lname = document.getElementsByName('lname')[0].value;
    var email = document.getElementsByName('email')[0].value;
    var dob = document.getElementsByName('dob')[0].value;
    var pass = document.getElementsByName('pass')[0].value;
    var cpass = document.getElementsByName('cpass')[0].value;

    // Perform validation
    if (fname === '' || lname === '' || email === '' || dob === '' || pass === '' || cpass === '') {
        alert('Please fill in all the required fields.');
        return;
    }

    if (!validateEmail(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    if (pass !== cpass) {
        alert('Password and Confirm Password do not match.');
        return;
    }

    // Move to next step
    document.getElementById('first').style.display = 'none';
    document.getElementById('second').style.display = 'block';
    document.getElementById('active1').classList.remove('active');
    document.getElementById('active2').classList.add('active');
}

function prev_step1() {
    // Move to previous step
    document.getElementById('first').style.display = 'block';
    document.getElementById('second').style.display = 'none';
    document.getElementById('active1').classList.add('active');
    document.getElementById('active2').classList.remove('active');
}

function next_step2() {
    // Get input field values
    var faculty_stream = document.getElementsByName('faculty_stream')[0].value;
    var joining_year = document.getElementsByName('joining_year')[0].value;
    var grad_year = document.getElementsByName('grad_year')[0].value;
    var degree = document.getElementsByName('Degree')[0].value;
    var reg_no = document.getElementsByName('Reg_no')[0].value;

    // Perform validation
    if (faculty_stream === '--Select Faculty--' || joining_year === '--Year Of Joining--' || grad_year === '--Graduation Year--' || degree === '' || reg_no === '') {
        alert('Please fill in all the required fields.');
        return;
    }
    // Perform registration number validation
    if (!validateNumeric(reg_no)) {
        alert('Please enter a valid registration number (numeric values only).');
        return;
    }

    // Move to next step
    document.getElementById('second').style.display = 'none';
    document.getElementById('third').style.display = 'block';
    document.getElementById('active2').classList.remove('active');
    document.getElementById('active3').classList.add('active');
}

// Add more validation functions for other fields if needed
// Function to validate numeric value
function validateNumeric(value) {
    var numericRegex = /^[0-9]*$/;
    return numericRegex.test(value);
}

function validateEmail(email) {
    // Email validation regex pattern
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}
// ...

function prev_step2() {
    // Move to previous step
    document.getElementById('second').style.display = 'block';
    document.getElementById('third').style.display = 'none';
    document.getElementById('active2').classList.add('active');
    document.getElementById('active3').classList.remove('active');
}

function next_step3() {
    // Get input field values
    var phoneNumber = document.getElementsByName('phone_number')[0].value;
    var working = document.querySelector('input[name="working"]:checked');
    var gender = document.querySelector('input[name="gender"]:checked');
    var jobTitle = document.getElementsByName('jobtitle')[0].value;
    var social = document.getElementsByName('social')[0].value;
    var address = document.getElementsByName('address')[0].value;

    // Perform validation
    if (phoneNumber === '' || !/^\d+$/.test(phoneNumber)) {
        alert('Please enter a valid numerical phone number.');
        return;
    }

    if (!working) {
        alert('Please select if you are currently working or not.');
        return;
    }

    if (!gender) {
        alert('Please select your gender.');
        return;
    }

    if (jobTitle === '') {
        alert('Please enter your job title.');
        return;
    }

    if (social === '') {
        alert('Please enter your social media URL.');
        return;
    }

    if (address === '') {
        alert('Please enter your current address.');
        return;
    }

    // Move to next step
    document.getElementById('third').style.display = 'none';
    document.getElementById('fourth').style.display = 'block';
    document.getElementById('active3').classList.remove('active');
    document.getElementById('active4').classList.add('active');
}

function prev_step3() {
    // Move to previous step
    document.getElementById('third').style.display = 'block';
    document.getElementById('fourth').style.display = 'none';
    document.getElementById('active3').classList.add('active');
    document.getElementById('active4').classList.remove('active');
}

function submitForm() {
    // Get input field values
    var phoneNumber = document.getElementsByName('phone_number')[0].value;
    var working = document.querySelector('input[name="working"]:checked');
    var gender = document.querySelector('input[name="gender"]:checked');
    var jobTitle = document.getElementsByName('jobtitle')[0].value;
    var social = document.getElementsByName('social')[0].value;
    var address = document.getElementsByName('address')[0].value;

    // Perform validation
    if (phoneNumber === '' || !/^\d+$/.test(phoneNumber)) {
        alert('Please enter a valid numerical phone number.');
        return;
    }

    if (!working) {
        alert('Please select if you are currently working or not.');
        return;
    }

    if (!gender) {
        alert('Please select your gender.');
        return;
    }

    if (jobTitle === '') {
        alert('Please enter your job title.');
        return;
    }

    if (social === '') {
        alert('Please enter your social media URL.');
        return;
    }

    if (address === '') {
        alert('Please enter your current address.');
        return;
    }

    // Submit the form
    document.forms['myForm'].submit();
}
