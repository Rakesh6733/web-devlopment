from django.contrib import admin
from .models import *
# Register your models here.

class UAdmin(admin.ModelAdmin):
    list_display = ('id', 'fname', 'lname', 'email', 'cpass', 'phone_number', 'img', 'social')

class Job_detailsAdmin(admin.ModelAdmin):
    list_display = ('jobname', 'desc', 'Type', 'duration', 'salary', 'link')

admin.site.register(U, UAdmin)
admin.site.register(Job_details)
admin.site.register(Alumni)
admin.site.register(Contact)
admin.site.register(Gallery)
admin.site.register(News)
admin.site.register(Profile)